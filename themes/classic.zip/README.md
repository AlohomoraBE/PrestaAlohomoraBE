# PrestaShop Classic Theme

The Classic Theme is the default Theme for Prestashop 1.7 and onwards.
It is built upon the Starter Theme which is not maintained anymore.
