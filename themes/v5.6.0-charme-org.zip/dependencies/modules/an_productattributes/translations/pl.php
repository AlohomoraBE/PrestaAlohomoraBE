<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{an_productattributes}prestashop>productattributes_2d0f6b8300be19cf35e89e66f0677f95'] = 'Dodaj do koszyka';
$_MODULE['<{an_productattributes}prestashop>product-select_9dd4efd8db6c4efc44d4010668ed2f85'] = ' wybierz wariant';
$_MODULE['<{an_productattributes}prestashop>product-select_679db092832473607ad10034a636ac90'] = 'Wyprzedane';
$_MODULE['<{an_productattributes}prestashop>product-select_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
