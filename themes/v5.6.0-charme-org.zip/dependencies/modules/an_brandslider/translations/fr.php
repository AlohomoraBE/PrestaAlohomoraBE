<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{an_brandslider}prestashop>an_brandslider_b9973b7494f64fe3b8f637ab6694efbb'] = 'AN Brand Slider partenaires fabricants logo carousel';
$_MODULE['<{an_brandslider}prestashop>an_brandslider_f0bf33e3e90485ad6f19e77da2c55a5c'] = 'Montre les marques présentées dans le magasin';
$_MODULE['<{an_brandslider}prestashop>an_brandslider_b22c8f9ad7db023c548c3b8e846cb169'] = 'Titre du bloc';
$_MODULE['<{an_brandslider}prestashop>an_brandslider_747512f0911bddca3223167293be7716'] = 'Afficher le titre du bloc';
$_MODULE['<{an_brandslider}prestashop>an_brandslider_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{an_brandslider}prestashop>an_brandslider_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{an_brandslider}prestashop>an_brandslider_b78a3223503896721cca1303f776159b'] = 'Titre';
$_MODULE['<{an_brandslider}prestashop>an_brandslider_c9cc8cce247e49bae79f15173ce97354'] = 'Sauvegarder';
$_MODULE['<{an_brandslider}prestashop>an_brandslider_2377be3c2ad9b435ba277a73f0f1ca76'] = 'Fabricants';
$_MODULE['<{an_brandslider}prestashop>an_brandslider_93d74901738e996378295fb0a59bb977'] = 'Paramètres de base';
$_MODULE['<{an_brandslider}prestashop>an_brandslider_aec1061851454a79749e740a815d4352'] = 'Réglages responsive ';
$_MODULE['<{an_brandslider}prestashop>form_17a1352d3f69a733fd472fce0238a07d'] = 'Indication du numéro d\'identification du produit';
$_MODULE['<{an_brandslider}prestashop>form_6bb999afde6fca60d70edce79d20b370'] = 'Le numéro d\'identification du produit';
$_MODULE['<{an_brandslider}prestashop>form_3ee3549ff0c93372a730749f784e9438'] = 'Sélectionnez un seul élément';
$_MODULE['<{an_brandslider}prestashop>form_e1b11c03820641dd1d1441bf68898d08'] = 'Changer la position';
$_MODULE['<{an_brandslider}prestashop>form_3713a99a6284e39061bd48069807aa52'] = 'élément sélectionnés';
$_MODULE['<{an_brandslider}prestashop>form_8fb31b552d63ffef9df733646a195bc0'] = 'élément disponibles';
$_MODULE['<{an_brandslider}prestashop>form_1063e38cb53d94d386f21227fcd84717'] = 'Supprimer';
$_MODULE['<{an_brandslider}prestashop>form_ec211f7c20af43e742bf2570c3cb84f9'] = 'Ajouter';
$_MODULE['<{an_brandslider}prestashop>slider_c70ad5f80e4c6f299013e08cabc980df'] = 'En savoir plus sur %s';
