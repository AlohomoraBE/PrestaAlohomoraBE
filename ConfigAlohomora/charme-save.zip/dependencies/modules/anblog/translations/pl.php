<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{anblog}prestashop>single_post_a5d491060952aa8ad5fdee071be752de'] = 'Komentarze';
$_MODULE['<{anblog}prestashop>_local_comment_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Komentarze';
$_MODULE['<{anblog}prestashop>miniature-post-type1_a5d491060952aa8ad5fdee071be752de'] = 'Komentarze';
$_MODULE['<{anblog}prestashop>_hp_listing_blog_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Komentarze';
$_MODULE['<{anblog}prestashop>comment_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Komentarze';
$_MODULE['<{anblog}prestashop>miniature-post-type2_a5d491060952aa8ad5fdee071be752de'] = 'Komentarze';
$_MODULE['<{anblog}prestashop>miniature-post-type3_a5d491060952aa8ad5fdee071be752de'] = 'Komentarze';
$_MODULE['<{anblog}prestashop>_listing_blog_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Komentarze';
