$(function(){
  $('.btn-close-line').click(function() {
    $(this).parent().slideUp('fast');
  });
});