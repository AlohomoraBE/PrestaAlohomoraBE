<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{anthemeblocks}prestashop>item_bff59c310e5dbc40ad00567a3cf8d103'] = 'Compra ahora';
$_MODULE['<{anthemeblocks}prestashop>big_43340e6cc4e88197d57f8d6d5ea50a46'] = 'Aprende más';
$_MODULE['<{anthemeblocks}prestashop>middle_43340e6cc4e88197d57f8d6d5ea50a46'] = 'Aprende más';
$_MODULE['<{anthemeblocks}prestashop>big_bff59c310e5dbc40ad00567a3cf8d103'] = 'Compra ahora';
